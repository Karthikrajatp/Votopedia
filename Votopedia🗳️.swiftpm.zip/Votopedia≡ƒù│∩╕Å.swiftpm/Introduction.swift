import SwiftUI

struct Introduction: View {
    @EnvironmentObject var soundSettings: SoundSettings
    @State private var isLabelAnimated = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.opacity(1)
                    .ignoresSafeArea()
                VStack {
                    HStack {
                        Text("Votopedia 🗳️")
                            .font(.system(size: 60, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .padding()
                            .font(.title)
                            .fontWeight(.heavy)
                        Button(action: {
                            soundSettings.togglePlayPause()
                        }) {
                            Text(soundSettings.isPlaying ? "🔇" : "🔈")
                                .buttonStyle(.bordered)
                                .padding()
                                .font(.system(size: 40,weight: .bold, design:.rounded))
                                .font(.system(.title))
                                .fontWeight(.heavy)
                             .scaleEffect(isLabelAnimated ? 0.8 : 1.0)
                        }
                    }
                    .padding(.bottom)
                    Text("👴🏻: Hi 👋!! Welcome to Votopedia🗳️, I'm Mr.Oldo, here to guide the young generation through the voting process. Let's explore together as we gear up for the upcoming elections in India 🇮🇳 and the USA 🇺🇸! Choose your journey and let's dive into the realm 👑 of Election.....")
                        .font(.system(size: 21, weight: .bold, design: .monospaced))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .padding()
                        .padding(.top)
                    
                    HStack {
                        NavigationLink(destination: IndiaHome().navigationBarBackButtonHidden()) {
                            Text("India 🇮🇳")
                                .font(.system(size: 40, weight: .semibold, design: .rounded))
                                .foregroundColor(.white)
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.blue, lineWidth: 2)
                                        .background(Color.blue)
                                        .cornerRadius(20)
                                )
                                .scaleEffect(isLabelAnimated ? 0.9 : 1.0)
                        }
                        .padding(20)
                        .onAppear {
                            withAnimation(.easeInOut(duration: 0.9).repeatForever()) {
                                isLabelAnimated = true
                            }
                        }
                        
                        NavigationLink(destination: USAHome().navigationBarBackButtonHidden()) {
                            Text("USA 🇺🇸")
                                .font(.system(size: 40, weight: .semibold, design: .rounded))
                                .foregroundColor(.white)
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(Color.blue, lineWidth: 2)
                                        .background(Color.blue)
                                        .cornerRadius(20)
                                )
                                .scaleEffect(isLabelAnimated ? 0.9 : 1.0)
                        }
                        .padding(20)
                    }
                }
            }
        }
    }
}


