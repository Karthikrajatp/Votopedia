import SwiftUI

struct Conclusion: View {
    @State private var isLabelAnimated = false
    @Environment(\.colorScheme) var colorScheme
    var body: some View {
        ZStack{
            NavigationStack{
                VStack{
                    VStack(alignment: .leading){
                        Text("Time to Think 🤔")
                            .padding(.horizontal,10)
                            .font(.system(size: 60, weight: .bold, design: .rounded))
                            .padding()
                        
                        Text("👴🏿: Finally we have arrived at the end of our Votopedia🗳️ journey.As you step into the realm of Election👑, let me impart a few words of wisdom💡.....")
                            .padding(.horizontal,50)
                            .multilineTextAlignment(.center)
                            .font(.system(size: 20,weight: .ultraLight, design:.serif))
                            .bold()
                        Divider()
                        Spacer()
                        
                    }
                    Text("Voting 🗳️ is a big deal.The right to vote is a precious gift 🎁, hard-won by those who came before you.")
                        .padding().frame(alignment: .center)
                        .bold()
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.center)
                        .padding()
                        .padding(.top)
                    Text("It's your chance to shape the future 🔮, so take it seriously. Learn about the issues 😌, don't just follow the crowd. And remember, every vote matters, even if it feels like it doesn't.")
                        .padding().frame(alignment: .center)
                        .bold()
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.center)
                        .padding()
                        .padding(.top)
                    Text("The decline 📉 in voter turnout is worrying 😔, but we can turn it around by getting more involved. So, don't sit on the sidelines—your voice 💪🏻 counts!").padding().frame(alignment: .center)
                        .bold()
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.center)
                        .padding()
                        .padding(.top)
                    
                    
                }
                NavigationLink {
                    Introduction().navigationBarBackButtonHidden(true)
                } label: {
                    Text("Try a new Journey🗳️")
                }
                .buttonStyle(.bordered)
                .font(.system(size: 30,weight: .heavy,design: .monospaced))
                .padding(.top,10)
                .padding(.bottom,100)
                
                
                Spacer()
                
                Divider()
                
                VStack{
                    Text("Designed and Developed with ❤️ by KarthikRaja T P for WWDC2024")
                        .font(.system(.footnote, design: .rounded, weight: .semibold))
                    Text("Created using the Swift Playgrounds and Xcode🔨")
                        .font(.system(.footnote, design: .rounded, weight: .semibold))
                    Text("Flag Images were obtained from Freepik.com")
                        .font(.system(.footnote, design: .rounded, weight: .semibold))
                    Text("Music: Appeasement by Oleg Mazur from SoundCloud.com")
                        .font(.system(.footnote, design: .rounded, weight: .semibold))
                }
                Spacer()
                
            }
        }
    }
}



