import SwiftUI
import UniformTypeIdentifiers


struct ElectionTrackerIndiaResults: View {
    
    @State private var taskshuffled = [
        "1.Wakeup⏰", "2.Preparation 🛁🍽️", "3.Polling Location Travel📍","4.Stand in queue🐜", "5.Verify ID 🆔","6.Cast Vote🗳️",  "7.Post on Socialmedia📱", "8.Follow Updates on Result📢"
    ]
    
    @State private var isWinning = true
    
    var body: some View {
        ZStack{
            Color.black.opacity(0.6)
                .ignoresSafeArea()
            VStack{
                NavigationStack{
                    ScrollView {
                        VStack{
                            Text("Election Day🎉")
                                .padding(.horizontal,10)
                                .font(.system(size: 60, weight: .bold, design: .rounded))
                                .foregroundColor(Color.white)
                                .padding()
                            Text("👴🏼: Finally its April 2024🥳, and you have got the opportunity to vote 🗳️!!. The below cards are the routine on an election day and they have been shuffled🔀 try changing the order to complete👍🏼 the process of Voting!!").font(.system(size: 20,weight: .ultraLight, design:.monospaced))
                                .padding(.horizontal,10)
                                .foregroundStyle(.white)
                                .frame(alignment: .center)
                                .bold()
                            Divider().overlay(Color.white)
                            Spacer()
                        }
                        
                        
                        LazyVStack(spacing:10) {
                            ForEach(taskshuffled, id: \.self) { task in
                                TaskCardView(task: task)
                            }
                        }
                        .padding()
                        .onDrop(of: [UTType.text], delegate: DragDropDelegate(taskshuffled: $taskshuffled, onWin: { self.isWinning = true }))
                        
                        if !isWinning{
                            NavigationLink{
                                Conclusion()
                            }label: {
                                Text(" Skip ⏭️")
                                    .foregroundColor(Color.white)
                                    .font(.system(size: 23,weight: .semibold,design: .rounded))
                            }
                            .buttonStyle(.borderedProminent)
                            .padding(.vertical,30)
                        }
                        
                        if isWinning {
                            Text("Congratulations🥂! You have completed✅ the process of 🗳️!!")
                                .bold()
                                .font(.system(size: 30, weight: .bold, design: .rounded))
                                .foregroundColor(.green)
                                .padding()
                            NavigationLink{
                                Conclusion()
                            }label: {
                                Text("Next ➡️")
                                    .foregroundColor(Color.white)
                                    .font(.system(size: 25,weight: .semibold,design: .rounded))
                            }
                            .buttonStyle(.bordered)
                            .padding(.vertical,30)
                        }
                    }
                }
            }
        }
    }
    
}



