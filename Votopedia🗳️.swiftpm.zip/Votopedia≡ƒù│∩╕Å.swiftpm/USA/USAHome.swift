import SwiftUI
import Charts

struct USAHome: View {
    
    var data = [
        VoteData(year: "2004", turnout: 60.1),
        VoteData(year: "2008", turnout: 61.6),
        VoteData(year: "2012", turnout: 58.6),
        VoteData(year: "2016", turnout: 57.3),
        VoteData(year: "2020", turnout: 66.6)
    ]
    
    @State private var selectedDate = Date()
    @State private var isUSACitizen = false
    @EnvironmentObject var soundSettings: SoundSettings
    @State private var isLabelAnimated = false
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.black.opacity(0.8)
                    .ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 20) {
                        CountryLabel(image: Image("usa"))
                            .padding()
                        Button(action: {
                            soundSettings.togglePlayPause()
                        }) {
                            Text(soundSettings.isPlaying ? "🔇" : "🔈")
                                .buttonStyle(.borderless)
                                .padding()
                                .padding(.bottom,30)
                                .font(.system(size: 40,weight: .bold, design:.rounded))
                                .font(.system(.title))
                                .fontWeight(.heavy)
                            .scaleEffect(isLabelAnimated ? 0.8 : 1.0)
                        }
                        
                        Text("👴🏾: The United States of America 🇺🇸, often referred to as the USA, is a federal republic composed of 5️⃣0️⃣ states. Renowned for its diverse population and cultural influences, it stands as a global🌎 economic and political powerhouse👑. Its presidential elections, held every 4️⃣ years, captivate the world's attention, featuring a complex process involving primaries, caucuses, and the Electoral College. These elections play a pivotal role in shaping not only domestic policies📖 but also international relations🤝, reflecting the nation's democratic principles and the will of its citizens.")
                            .font(.system(size: 20))
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.secondary.opacity(0.1))
                            .cornerRadius(10)
                            .bold()
                        
                        Divider().overlay(.white)
                        
                        VStack(spacing: 20) {
                            Text("Voter Turnout (%)")
                                .font(.title2)
                                .bold()
                                .foregroundStyle(.white)
                            Chart {
                                ForEach(data) { d in
                                    BarMark(x: PlottableValue.value("Year", d.year), y: .value("Turnout", d.turnout))
                                        .annotation(position: .automatic) {
                                            Text("\(String(format: "%.1f", d.turnout))%")
                                                .bold()
                                        }
                                }
                            }
                            .padding(20)
                            .background(Color.blue.opacity(0.4))
                            .cornerRadius(10)
                            
                            Text("👴🏾: The bar chart shows the turnout percentage of the last five previous elections.")
                                .font(.caption)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.white)
                        }
                        .padding(.horizontal)
                        
                        Divider().overlay(.white.opacity(0.9))
                        
                        VStack {
                            Text("Check your Voting Eligibility📋")
                                .font(.title2)
                                .foregroundStyle(.white)
                                .bold()
                                .padding(.bottom, 5)
                            HStack{
                                Toggle("Are you a citizen of the USA?", isOn: $isUSACitizen)
                                    .padding(.trailing, 10)
                                    .bold()
                                    .padding(.horizontal, 20)
                                    .frame(maxWidth: .infinity)
                                    .font(.system(size: 16))
                                    .foregroundStyle(.white)
                                    .toggleStyle(SwitchToggleStyle(tint: .white.opacity(0.9)))
                                
                                DatePicker("Date of Birth🎂", selection: $selectedDate, displayedComponents: .date)
                                    .bold()
                                    .datePickerStyle(WheelDatePickerStyle())
                                    .padding()
                                    .background(Color.blue.opacity(0.8))
                                    .cornerRadius(10)
                                    .padding(.horizontal, 20)
                                    .frame(maxWidth: .infinity)
                                    .font(.system(size: 16))
                            }
                            .padding(.horizontal)
                            
                            
                            Text(votingEligibilityMessage())
                                .font(.headline)
                                .foregroundColor(votingEligibilityColor())
                                .padding()
                                .font(.system(size: 20,weight: .bold, design:.rounded))
                                .background(Color.secondary.opacity(0.4))
                                .cornerRadius(10)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .padding(.horizontal)
                        NavigationLink{
                            ElectionUSAQuiz()
                        }label: {
                            Text("Continue ➡️")
                                .foregroundColor(Color.white)
                                .font(.system(size: 25,weight: .semibold,design: .rounded))
                        }
                        .buttonStyle(.bordered)
                        .padding(.vertical,30)
                    }
                    Text("Note: Voting eligibility criteria may vary by state. Please check the regulations in your state. Eligibility is based on the election date of November 5, 2024.")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .padding(.vertical, 20)
                }
            }
        }
    }
    
    func checkAge() -> Bool {
        if isUSACitizen {
            let calendar = Calendar.current
            let birthDate = calendar.startOfDay(for: selectedDate)
            let comparisonDate = calendar.date(from: DateComponents(year: 2024, month: 11, day: 5))!
            
            if let age = calendar.dateComponents([.year], from: birthDate, to: comparisonDate).year {
                return age < 18
            }
        }
        return true 
    }
    
    func votingEligibilityMessage() -> String {
        if isUSACitizen {
            return checkAge() ? "👴🏾: You are ❌ eligible to 🗳️" : "👴🏾: You are ✅ eligible to 🗳️"
        } else {
            return "👴🏾: Please confirm your US citizenship status"
        }
    }
    
    func votingEligibilityColor() -> Color {
        if !isUSACitizen {
            return .white
        }
        
        return checkAge() ? .red : .green
    }
}

