import SwiftUI
import AVFoundation


struct QuizQuestion:  Identifiable{
    let id = UUID()
    let question: String
    let answers: [String]
    let correctAnswer: Int
}

struct ElectionUSAQuiz: View {
    @State private var isSoundPlaying = true
    @State private var isLabelAnimated = false
    @Environment(\.colorScheme) var colorScheme
    
    let questions = [QuizQuestion(question: "🗳️ How often are presidential elections held in the 🇺🇸❓", answers: ["2 years","4 years","6 years","8 years"], correctAnswer: 1),
                     QuizQuestion(question: "🗳️ What is the minimum age requirement to be eligible to vote in federal elections in the 🇺🇸❓", answers: ["16 years old","17 years old","18 years old","20 years old"], correctAnswer: 2),
                     QuizQuestion(question: "🗳️ Which of the following amendments to the 🇺🇸 Constitution granted women 👸🏻 the right to vote❓", answers: ["13th","19th","14th","15th"], correctAnswer: 1),
                     QuizQuestion(question: "🗳️ How many total electoral votes are there in the Electoral College?", answers: ["350","160","543","538"], correctAnswer: 3),
                     QuizQuestion(question:  "🗳️ How many branches of government are there in the 🇺🇸❓", answers: ["Three","Two","One","Four"], correctAnswer:0 )]
    
    
    @State private var currentQuestionIndex = 0
    @State private var selectedAnswerIndex: Int?
    @State private var isCorrect = false
    
    var body: some View {
        NavigationStack{
            ZStack{
                Color.black.opacity(0.6)
                    .ignoresSafeArea()
                VStack{
                    VStack(alignment:.leading){
                        Text("Test 🎯")
                            .font(.system(size: 60, weight: .bold, design: .rounded))
                            .padding()
                            .foregroundColor(.white)
                        Text("👴🏽: Before getting into the voting part lets test your knowledge on the Politics and the Governance of USA 🇺🇸")
                            .padding(.horizontal,10)
                            .padding(.bottom,10)
                            .font(.system(size: 20,weight: .bold, design:.monospaced))
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white)
                        Divider().overlay(.white)
                        
                    }
                    if currentQuestionIndex<5{
                        VStack{
                            Text(questions[currentQuestionIndex].question)
                                .font(.title)
                                .padding(.top)
                                .foregroundStyle(.white)
                            VStack{
                                HStack {
                                    Button(action: {
                                        selectedAnswerIndex = 0
                                        isCorrect = selectedAnswerIndex == questions[currentQuestionIndex].correctAnswer
                                    }) {
                                        Text(questions[currentQuestionIndex].answers[0])
                                            .scaledToFill()
                                            .font(.system(size: 25,weight: .bold,design: .rounded))
                                            .padding()
                                            .foregroundStyle(.white)
                                    }
                                    .frame(width: 200,height: 70)
                                    .padding(.vertical)
                                    .background(selectedAnswerIndex == 0 ? (isCorrect ? Color.green : Color.red) : Color.clear)
                                    .cornerRadius(15)
                                    
                                    Button(action: {
                                        selectedAnswerIndex = 1
                                        isCorrect = selectedAnswerIndex == questions[currentQuestionIndex].correctAnswer
                                        
                                    }) {
                                        Text(questions[currentQuestionIndex].answers[1])
                                            .scaledToFit()
                                            .font(.system(size: 25,weight: .bold,design: .rounded))
                                            .padding()
                                            .foregroundStyle(.white)
                                    }
                                    .frame(width: 200,height: 70)
                                    .padding(.vertical)
                                    .background(selectedAnswerIndex == 1 ? (isCorrect ? Color.green : Color.red) : Color.clear)
                                    .cornerRadius(15)
                                    
                                }
                                
                                HStack {
                                    Button(action: {
                                        selectedAnswerIndex = 2
                                        isCorrect = selectedAnswerIndex == questions[currentQuestionIndex].correctAnswer
                                        
                                    }) {
                                        Text(questions[currentQuestionIndex].answers[2])
                                            .scaledToFit()
                                            .font(.system(size: 25,weight: .bold,design: .rounded))
                                            .padding()
                                            .foregroundStyle(.white)
                                        
                                    }
                                    .frame(width: 200,height: 70)
                                    .padding(.vertical)
                                    .background(selectedAnswerIndex == 2 ? (isCorrect ? Color.green : Color.red) : Color.clear)
                                    .cornerRadius(15)
                                    
                                    Button(action: {
                                        selectedAnswerIndex = 3
                                        isCorrect = selectedAnswerIndex == questions[currentQuestionIndex].correctAnswer
                                        
                                    }) {
                                        Text(questions[currentQuestionIndex].answers[3])
                                            .scaledToFit()
                                            .font(.system(size: 25,weight: .bold,design: .rounded))
                                            .padding()
                                            .foregroundStyle(.white)
                                    }
                                    .frame(width: 200,height: 70)
                                    .padding(.vertical)
                                    .background(selectedAnswerIndex == 3 ? (isCorrect ? Color.green : Color.red) : Color.clear)
                                    .cornerRadius(15)
                                    
                                    
                                }
                                
                                Button("Next ➡️") {
                                    if selectedAnswerIndex != nil {
                                        if selectedAnswerIndex == questions[currentQuestionIndex].correctAnswer {
                                            if currentQuestionIndex<5{
                                                currentQuestionIndex += 1
                                                selectedAnswerIndex = nil
                                            }else{
                                                currentQuestionIndex = 0
                                                selectedAnswerIndex = nil
                                            }
                                        }
                                    }
                                }
                                .foregroundColor(Color.white)
                                .font(.system(size: 25,weight:.semibold,design:.rounded))
                                .background(selectedAnswerIndex == nil ? Color.gray : Color.blue)
                                .cornerRadius(10)
                                .padding(.top,40)
                                .disabled(selectedAnswerIndex == nil)
                                .buttonStyle(.bordered)
                                
                            }
                        }
                    }else{
                        VStack{
                            Text("👴🏽: Congratulations Mate! You have answered all the questions now lets fastforward⏳ time and land at November 5,2024.🗓️")
                                .padding()
                                .padding(.top)
                                .font(.system(size: 18, weight: .semibold, design:.monospaced))
                                .foregroundStyle(.white)
                                .multilineTextAlignment(.center)
                            
                            NavigationLink {
                                ElectionTrackerUSA().navigationBarBackButtonHidden(true)
                            } label: {
                                Text("Continue ➡️")
                            }
                            .foregroundColor(Color.white)
                            .font(.system(size: 25,weight:.semibold,design:.rounded))
                            .buttonStyle(.bordered)
                            .padding(.top)
                            .foregroundColor(Color.white)
                            
                        }
                    }
                }
            }
        }
    }
}

