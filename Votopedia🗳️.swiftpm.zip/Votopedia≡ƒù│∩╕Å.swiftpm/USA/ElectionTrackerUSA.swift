import SwiftUI
import UniformTypeIdentifiers


struct ElectionTrackerUSA: View {
    @EnvironmentObject var soundSettings: SoundSettings
    @State private var taskshuffled = [
        "Wakeup⏰", "Preparation 🛁🍽️", "Polling Location Travel📍","Stand in queue🐜", "Verify ID 🆔","Cast Vote🗳️", "Post on Socialmedia📱", "Follow Updates on Result📢"
    ].shuffled()
    
    @State private var isWinning = false
    @State private var isLabelAnimated = false
    
    var body: some View {
        VStack{
            NavigationStack{
                ZStack{
                    Color.black.opacity(0.6)
                        .ignoresSafeArea()
                    ScrollView {
                        VStack{
                            HStack{
                                Text("Election Day🎉")
                                    .padding(.horizontal,10)
                                    .font(.system(size: 60, weight: .bold, design: .rounded))
                                    .foregroundColor(Color.white)
                                    .padding()
                                Button(action: {
                                    soundSettings.togglePlayPause()
                                }) {
                                    Text(soundSettings.isPlaying ? "🔇" : "🔈")
                                        .buttonStyle(.borderless)
                                        .padding()
                                        .font(.system(size: 40,weight: .bold, design:.rounded))
                                        .font(.system(.title))
                                        .fontWeight(.heavy)
                                        .scaleEffect(isLabelAnimated ? 0.8 : 1.0)
                                }
                            }
                            Text("👴🏼: Finally its November 5,2024🥳, and you have got the opportunity to vote 🗳️!!. The below cards are the routine on an election day and they have been shuffled🔀 try changing the order to complete👍🏼 the process of Voting!!").font(.system(size: 20,weight: .ultraLight, design:.monospaced))
                                .padding(.horizontal,10)
                                .foregroundStyle(.white)
                                .frame(alignment: .center)
                                .bold()
                            Divider().overlay(Color.white)
                            Spacer()
                        }
                        
                        
                        LazyVStack(spacing:10) {
                            ForEach(taskshuffled, id: \.self) { task in
                                TaskCardView(task: task)
                            }
                        }
                        .padding()
                        .onDrop(of: [UTType.text], delegate: DragDropDelegate(taskshuffled: $taskshuffled, onWin: { self.isWinning = true }))
                        
                        if !isWinning{
                            NavigationLink{
                                ElectionTrackerUSAResults()
                            }label: {
                                Text(" Skip ⏭️")
                                    .foregroundColor(Color.white)
                                    .font(.system(size: 23,weight:.semibold,design:.rounded))
                                    .cornerRadius(10)
                                    .padding()
                                
                            }
                            .buttonStyle(.borderedProminent)
                            .padding(.vertical,30)
                            
                            
                        }
                        
                        if isWinning {
                            Text("Congratulations 🥂! You have completed✅ the process of 🗳️!!")
                                .bold()
                                .font(.system(size: 30, weight: .bold, design: .rounded))
                                .foregroundColor(.green)
                                .padding()

                    
                            NavigationLink{
                                Conclusion()
                            }label: {
                                Text("Next ➡️")
                                    .foregroundColor(Color.white)
                                    .font(.system(size: 25,weight: .semibold,design: .rounded))
                            }
                            .buttonStyle(.bordered)
                            .padding(.vertical,30)
                        }
                    }
                }
            }
        }
    }
}






