import SwiftUI

struct ContentView: View {
    var body: some View {
        Introduction().environmentObject(SoundSettings())
    }
}


