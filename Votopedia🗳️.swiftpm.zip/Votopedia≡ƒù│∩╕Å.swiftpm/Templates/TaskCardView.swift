import SwiftUI
import UniformTypeIdentifiers

struct TaskCardView: View {
    var task: String
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white.opacity(0.9))
                .shadow(radius: 10)
                .frame(width: 270,height: 60)
            
            VStack {
                Text(task)
                    .font(.headline)
                    .padding()
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.black)
                
                Spacer()
            }
        }
        .padding()
        .onDrag { return NSItemProvider(object: task as NSString) }
    }
}
struct DragDropDelegate: DropDelegate {
    @State private var tasks = [
        "Wakeup⏰", "Preparation 🛁🍽️", "Polling Location Travel📍","Stand in queue🐜", "Verify ID 🆔","Cast Vote🗳️", "Post on Socialmedia📱", "Follow Updates on Result📢"
    ]
    @Binding var taskshuffled: [String]
    var onWin: () -> Void
    
    func performDrop(info: DropInfo) -> Bool {
        let itemProviders = info.itemProviders(for: [UTType.text])
        guard let itemProvider = itemProviders.first else { return false }
        
        _ = itemProvider.loadObject(ofClass: NSString.self) { item, _ in
            if let task = item as? String {
                DispatchQueue.main.async {
                    let fromIndex = taskshuffled.firstIndex(of: task)!
                    let toIndex = min(taskshuffled.count, max(0, self.index(from: info)))
                    taskshuffled.move(fromOffsets: IndexSet(integer: fromIndex), toOffset: toIndex)
                    
                    // Check if tasks are in correct order
                    if taskshuffled == tasks {
                        self.onWin()
                    }
                }
            }
        }
        return true
    }
    
    func index(from info: DropInfo) -> Int {
        let yOffset = info.location.y
        let cardHeight: CGFloat = 120
        let index = min(tasks.count, Int(yOffset / cardHeight))
        return index
    }
}
