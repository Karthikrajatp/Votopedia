import SwiftUI
import AVFoundation

class SoundSettings: ObservableObject {
    @Published var isPlaying = false
    var qplayer: AVAudioPlayer?
    
    func togglePlayPause() {
        guard let url = Bundle.main.url(forResource: "Appeasement", withExtension: "mp3") else {
            print("Sound file not found")
            return
        }
        
        if isPlaying {
            qplayer?.pause()
        } else {
            do {
                qplayer = try AVAudioPlayer(contentsOf: url)
                qplayer?.play()
            } catch {
                print("Error playing sound: \(error.localizedDescription)")
            }
        }
        isPlaying.toggle()
    }
}

