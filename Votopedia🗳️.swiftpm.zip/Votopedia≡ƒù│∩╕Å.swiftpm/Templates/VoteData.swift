import SwiftUI


struct VoteData:Identifiable{
    var id = UUID().uuidString
    var year: String
    var turnout: Double
}
